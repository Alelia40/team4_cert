module.exports = {
    'secret': 'mypass'
};